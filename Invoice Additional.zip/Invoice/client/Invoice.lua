local EnableToInvoice = {
    police = true,
    ambulance = true,
}

-- Grade
local EnableToEditInvoice = {
    police = 1,
    ambulance = 1,
}

RegisterNuiCallback('InvoiceInit', function(_, cb) 

    STPCustom.Functions.TriggerCallback('STPhone:Server:InvoiceInit', function(Invoices)
        if Invoices then
            local FinalReturn = {}

            FinalReturn.Invoices = Invoices

            local PlyDataJob = STPCustom.Functions.GetPlayerData().job

            FinalReturn.PlayerData = {
                EnableSend = EnableToInvoice[PlyDataJob.name] or false,
                EnableEdit = false
            }
            
            if EnableToEditInvoice[PlyDataJob.name] then 
                if PlyDataJob.grade.level >= EnableToEditInvoice[PlyDataJob.name] then 
                    FinalReturn.PlayerData.EnableEdit = true
                end
            end

            cb(FinalReturn)
        else
            local FinalReturn = {}

            FinalReturn.Invoices = {}
            
            local PlyDataJob = STPCustom.Functions.GetPlayerData().job

            FinalReturn.PlayerData = {
                EnableSend = EnableToInvoice[PlyDataJob.name] or false,
                EnableEdit = false
            }

            if EnableToEditInvoice[PlyDataJob.name] then 
                if PlyDataJob.grade.level >= EnableToEditInvoice[PlyDataJob.name] then 
                    FinalReturn.PlayerData.EnableEdit = true
                end
            end
            

            cb(FinalReturn)
        end
    end)
end)

RegisterNuiCallback('InvoiceInitSociety', function(_, cb) 

    STPCustom.Functions.TriggerCallback('STPhone:Server:InvoiceInitSociety', function(Invoices)
        if Invoices then
            local FinalReturn = {}            
            FinalReturn.Invoices = Invoices

            cb(FinalReturn)
        else
            cb(false)
        end
    end)
end)

RegisterNuiCallback('InvoiceDelete', function(Data, cb) 
    local DeleteID = Data.ID

    TriggerServerEvent('STPhone:Server:InvoiceDelete', DeleteID)

    cb('ok')
end)

RegisterNuiCallback('InvoicePay', function(Data, cb) 
    local PayId = Data.ID
    local Amount = Data.Amount
    local Society = Data.Society

    STPCustom.Functions.TriggerCallback('STPhone:Server:InvoicePay', function(AblePay)
        if AblePay then
            cb(true)
        else
            cb(false)
        end
    end, PayId, Amount, Society)
end)

RegisterNuiCallback('InvoiceCreate', function(Data, cb) 
    local Amount = Data.Amount
    local Description = Data.Descp
    local ped = PlayerPedId()

    local input = lib.inputDialog('Target Player ID', {'ID'})
 
    if not input then 
        cb(false)
        return
    end

    if input and input[1] then 
        STPCustom.Functions.TriggerCallback('STPhone:Server:InvoiceCreate', function(Created)
            if Created then
                cb(true)
            else
                cb(false)
            end
        end, tonumber(input[1]), Amount, Description)
    end

    --local Player, Distance = STPCore.Functions.GetClosestPlayer(GetEntityCoords(ped))
 --
    --if Player and Distance < 3.0 then
    --    STPCustom.Functions.TriggerCallback('STPhone:Server:InvoiceCreate', function(Created)
    --        if Created then
    --            cb(true)
    --        else
    --            cb(false)
    --        end
    --    end, GetPlayerServerId(Player), Amount, Description)
    --else
    --    cb(false)
    --end
end)

RegisterNuiCallback('PayAllInvoices', function(Data, cb) 
    local TotalPayAmount = Data.TotalPayAmount

    STPCustom.Functions.TriggerCallback('STPhone:Server:PayAllInvoices', function(Payed)
        if Payed then
            cb(true)
        else
            cb(false)
        end
    end, TotalPayAmount)
end)

