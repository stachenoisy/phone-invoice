local InvoiceTable = "stache_invoices"

STPCustom.Functions.CreateCallback('STPhone:Server:InvoiceInit', function(source)
    local p = promise:new()

    local Player = STPCustom.Functions.GetPlayer(source)
    if Player ~= nil then
        local Cid = STPCustom.Functions.GetPlayerCid(Player)

        MySQL.Async.fetchAll('SELECT * FROM `' .. InvoiceTable .. '` WHERE citizenid = ?', {
            Cid
        }, function(result)

            if result[1] ~= nil or result[1] then
                p:resolve(result)
            else
                p:resolve(false)
            end
        end)
        
    else
        p:resolve(false)
    end

    return Citizen.Await(p)
end)

STPCustom.Functions.CreateCallback('STPhone:Server:InvoiceInitSociety', function(source)
    local p = promise:new()

    local Player = STPCustom.Functions.GetPlayer(source)
    if Player ~= nil then
        local Job = Player.PlayerData.job.name

        MySQL.Async.fetchAll('SELECT * FROM `' .. InvoiceTable .. '` WHERE society = ?', {
            Job
        }, function(result)
            if result[1] ~= nil or result[1] then
                p:resolve(result)
            else
                p:resolve(false)
            end
        end)
        
    else
        p:resolve(false)
    end

    return Citizen.Await(p)
end)

RegisterNetEvent('STPhone:Server:InvoiceDelete', function(ID)
    MySQL.Async.execute('DELETE FROM `' .. InvoiceTable .. '` WHERE id = @id', {
        ['@id'] = ID
    }, function(affectedRows)
        -- if affectedRows > 0 then
        --     print('Invoice Deleted')
        -- else
        --     print('Invoice Not Deleted')
        -- end
    end)
end)

STPCustom.Functions.CreateCallback('STPhone:Server:InvoicePay', function(source, ID, Amount, Society)
    local p = promise:new()

    local Player = STPCustom.Functions.GetPlayer(source)
    if Player ~= nil then

        local BankMoney = STPCustom.Functions.GetPlayerBank(Player)

        if BankMoney >= Amount then
            STPCustom.Functions.RemoveMoney(Player, Amount)

            MySQL.Async.fetchAll('SELECT sendercitizenid FROM `' .. InvoiceTable .. '` WHERE id = ?', {
                ID
            }, function(result)
                if result[1] ~= nil or result[1] then
                    
                    local OtherCid = result[1].sendercitizenid

                    local OtherP = STPCustom.Functions.GetPlayerByCitizenId(OtherCid)
                    SenderMoney(OtherP, Amount, OtherCid)
                end
            end)

            MySQL.Async.execute('DELETE FROM `' .. InvoiceTable .. '` WHERE id = @id', {
                ['@id'] = ID
            }, function(affectedRows)
                if affectedRows > 0 then
                    p:resolve(true)
                else
                    p:resolve(false)
                end
            end)

        else
            p:resolve(false)
        end

    else
        p:resolve(false)
    end

    return Citizen.Await(p)
end)

STPCustom.Functions.CreateCallback('STPhone:Server:InvoiceCreate', function(source, TargetID, Amount, Description)
    local p = promise:new()

    local Player = STPCustom.Functions.GetPlayer(source)
    if Player ~= nil then

        local Target = STPCustom.Functions.GetPlayer(TargetID)

        if Target ~= nil then

            local TargetCid = STPCustom.Functions.GetPlayerCid(Target)

            MySQL.Async.execute('INSERT INTO `' .. InvoiceTable .. '` (citizenid, amount, society, sender, sendercitizenid, label) VALUES (@citizenid, @amount, @society, @sender, @sendercid, @label)', {
                ['@citizenid'] = TargetCid,
                ['@amount'] = Amount,
                ['@society'] = Player.PlayerData.job.name,
                ['@sender'] = Player.PlayerData.job.label,
                ['@sendercid'] = Player.PlayerData.citizenid,
                ['@label'] = Description or "Invoice"
            }, function(affectedRows)
                if affectedRows > 0 then
                    TriggerClientEvent('STPhone:GameNotify', Target.PlayerData.source, 'New Invoice Arrived!', 'info', 5000)
                    p:resolve(true)
                else
                    p:resolve(false)
                end
            end)

        else
            p:resolve(false)
        end

    else
        p:resolve(false)
    end

    return Citizen.Await(p)
end)

STPCustom.Functions.CreateCallback('STPhone:Server:PayAllInvoices', function(source, TotalPayAmount)
    local p = promise:new()

    local Player = STPCustom.Functions.GetPlayer(source)
    if Player ~= nil then

        local BankMoney = STPCustom.Functions.GetPlayerBank(Player)

        if BankMoney >= TotalPayAmount then
            STPCustom.Functions.RemoveMoney(Player, TotalPayAmount)

            MySQL.Async.fetchAll('SELECT * FROM `' .. InvoiceTable .. '` WHERE citizenid = ?', {
                Player.PlayerData.citizenid
            }, function(result)
                if result[1] ~= nil or result[1] then
                    
                    local SocietyInvoices = {}

                    for k, v in pairs(result) do
                        if SocietyInvoices[v.sendercitizenid] == nil then
                            SocietyInvoices[v.sendercitizenid] = v.amount
                        else
                            SocietyInvoices[v.sendercitizenid] = SocietyInvoices[v.sendercitizenid] + v.amount
                        end
                    end

                    for k, v in pairs(SocietyInvoices) do
                        local OtherP = STPCustom.Functions.GetPlayerByCitizenId(k)
                        SenderMoney(OtherP, v, k)
                    end

                else
                    p:resolve(false)
                end
            end)

            MySQL.Async.execute('DELETE FROM `' .. InvoiceTable .. '` WHERE citizenid = @citizenid', {
                ['@citizenid'] = Player.PlayerData.citizenid
            }, function(affectedRows)
                if affectedRows > 0 then

                    -- Success Payment Add Money To Account
                    -- 
                    -- 

                    p:resolve(true)
                else
                    p:resolve(false)
                end
            end)

        else
            p:resolve(false)
        end

    else
        p:resolve(false)
    end

    return Citizen.Await(p)
end)

function SenderMoney(Player, Amount, Cid)
    if Player ~= nil then
        STPCustom.Functions.AddMoney(Player, Amount, 'invoice-paid')
    else
        -- For QB-Core
        -- local response = MySQL.query.await('SELECT `money` FROM `players` WHERE citizenid = ?', {
        --     Cid
        -- })

        -- if response[1] ~= nil or response[1] then
        --     local Money = json.decode(response[1].money)
        --     Money.bank = Money.bank + Amount
        --     MySQL.Async.execute('UPDATE `players` SET `money` = @money WHERE citizenid = @citizenid', {
        --         ['@citizenid'] = Cid,
        --         ['@money'] = json.encode(Money)
        --     }, function(affectedRows)
        --         if affectedRows > 0 then
        --         end
        --     end)
        -- end
    end
end

RegisterNetEvent('STPhone:Server:CreateInvoiceEvent', function(TargetID, Amount, Description)
    local Player = STPCustom.Functions.GetPlayer(source)
    if Player ~= nil then

        local Target = STPCustom.Functions.GetPlayer(TargetID)

        if Target ~= nil then

            local TargetCid = STPCustom.Functions.GetPlayerCid(Target)

            MySQL.Async.execute('INSERT INTO `' .. InvoiceTable .. '` (citizenid, amount, society, sender, sendercitizenid, label) VALUES (@citizenid, @amount, @society, @sender, @sendercid, @label)', {
                ['@citizenid'] = TargetCid,
                ['@amount'] = Amount,
                ['@society'] = Player.PlayerData.job.name,
                ['@sender'] = Player.PlayerData.job.label,
                ['@sendercid'] = Player.PlayerData.citizenid,
                ['@label'] = Description or "Invoice"
            }, function(affectedRows)
                if affectedRows > 0 then
                    TriggerClientEvent('STPhone:GameNotify', Target.PlayerData.source, 'New Invoice Arrived!', 'info', 5000)
                end
            end)
        end
    end
end)