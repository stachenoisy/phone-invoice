CREATE TABLE IF NOT EXISTS `stache_invoices` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `amount` INT(11) NOT NULL,
    `society` VARCHAR(50) NOT NULL,
    `sender` VARCHAR(50) NOT NULL,
    `sendercitizenid` VARCHAR(50) NOT NULL,
    `label` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`)
)